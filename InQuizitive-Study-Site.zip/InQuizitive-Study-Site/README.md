
# InQuizitive-Study-Site

OVERVIEW:
The Inquisitive Study Site, or simply "ISS" exists to provide a place for students of any grade and/or age to come and utilize its tools. Inlcuded in these tools are practice exams, flashcards, and term vocabulary tables. The target demographic, students, can upload their own set of information, a study set, to use on the website for a given subject. This is how the ISS will build its database; through its users. The ISS was initially discussed to be a free alternative to other study resources already available online.

USAGE:
Anyone is able to use the ISS for free; however, to create a study set that is featured on the ISS, a user must make an account. After creating an account, users must navigate to the "Create Study Set" button through the tabs. In creating a study set, users will be prompted to enter, at minimum, 5 terms and their definitions. These terms and defintions will be displayed on the specified study set's template webpage, and can be utilized in practice exams and flashcards.

To use a study set and its terms, a user (with or without an account) must naviagte to the explore tab, or use the search bar, both of which are available from any webpage. Users must then naviagte to a desired study set through the various filters provided, as well as "user-defined" filters in the form of the search bar. After finding a set, users simply click on it, and are taken to the appropriate webpage with the pre-defined information.
